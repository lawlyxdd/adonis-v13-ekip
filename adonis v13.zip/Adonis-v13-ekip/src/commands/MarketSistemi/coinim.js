const dolar = require("../../schemas/dolar");
const conf = require("../../configs/sunucuayar.json")

module.exports = {
  conf: {
    aliases: [],
    name: "bakiye",
    help: "bakiye"
  },
  
  run: async (client, message, args, embed) => { 
const dolarData = await dolar.find({ guildID: message.guild.id, userID: message.author.id }).sort({ dolar: -1 });
let dolarSum = 0;
const dolarUsers = dolarData.splice(0, 5).map((x, index) => {
dolarSum += x.dolar;
return `\`${index+1}.\` <@${x.userID}>: \`${Number(x.dolar).toLocaleString()} dolar\` <:coin:1015538273407479881> `
}).join(`\n`);
message.channel.send({ embeds: [embed.setDescription(`
${dolarUsers.length > 0 ? dolarUsers : "Veri Bulunmuyor."}
`)]})
}
};